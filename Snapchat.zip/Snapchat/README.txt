Copy this folder onto your desktop, remove everything out (NOT INCLUDING THE README) and place onto your desktop.

Have Fun!

-AB